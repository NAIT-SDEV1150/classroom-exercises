console.log('Lesson 10 starter loaded');

// 1. Select required elements

// 2. Function to gather and structure form data
  // Instructor TODO: get the name
  
  // Student TODO: get the email and bio
  
  // OPTIONAL: get the plan and topic values as well
  
  // Instructor TODO: return the fullName within an object literal
  // Student TODO: add the remaining fields

// 3. Handle form submission
// Use 'submit' event on the form, not 'click' on the button
// Prevent default behavior (navigation/reload) using event.preventDefault()
  // Instructor TODO: display the fullName value

  // Student TODO: display the remaining values
  
// 4. Handle form reset - reset the result area text when the form is reset
