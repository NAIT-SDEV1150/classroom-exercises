console.log('Lesson 04 starter loaded');

// Instructor TODO:
// 1. Simple if
// 2. if-else
// 3. Nested if-else
// 4. while loop
// 5. do-while loop
// 6. for loop

// Student TODO:
// 7. Snippet with bugs for debugging practice
// Snippet with bugs for debugging practice - uncomment when ready
/*
const num = 10;

if (num < 5) {
  console.log('num is greater than 5');
} else {
  console.log('num is 5 or less');
}

let k = 0;
while (k < 3) {
  k + 1;
	console.log(k);
}
*/
