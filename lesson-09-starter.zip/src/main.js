console.log('Lesson 10 starter loaded');

// ============== Propagation demo

// 1. Select required elements

// 2. Add event listeners

// 2.1 Outer div - using a named function

// 2.2 Inner div - using an anonymous function

// 2.3 Button - using an arrow function

// ============== Gallery demo

// 1. Select required elements

// 2. Add event listeners

// 2.1 Thumbnails container - using an arrow function

// 2.2 Close button - using an arrow function

// Student TODO: Add event listener to document, which closes
// the viewer when the Escape key is pressed
