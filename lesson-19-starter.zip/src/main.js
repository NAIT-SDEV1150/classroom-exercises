// Import the user-card component to register the custom element

// Create an additional user card using HTML and append it to the main element

// Create another user card using JavaScript DOM API only and append it to the main element
