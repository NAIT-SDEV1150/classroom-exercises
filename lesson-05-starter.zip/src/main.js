console.log('Lesson 03 starter loaded');
