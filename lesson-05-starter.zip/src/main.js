console.log('Lesson 03 starter loaded');

// 1. Selecting elements

// 2. textContent vs innerHTML

// 3. Attributes & styles

// 4. Create small helper functions for reuse

// 5. Use helpers to perform simple tasks

// 6. Footer text tweak (demonstrate class toggle & style change)

// Require innerHTML here to render the &copy; entity correctly

// 7. Null-safety tip: check selections before using them
