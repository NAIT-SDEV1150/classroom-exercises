console.log('Lesson 05 starter loaded');

// 1. Selecting elements

// 2. textContent vs innerHTML
// When you only need text (no markup), prefer textContent:

// 3. Attributes & styles

// 4. Create small helper functions for reuse (updateText and updateHTML)
// OPTIONAL: more helpers for attributes and styles

// 5. Use helpers to perform simple tasks
// OPTIONAL: use attribute and style helpers if defined

// 6. Footer text tweak (demonstrate class toggle & style change)

// Require innerHTML here to render the &copy; entity correctly
