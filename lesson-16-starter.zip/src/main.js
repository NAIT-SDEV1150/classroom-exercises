// Import the functions necessary to make the API calls

// Select the necessary DOM elements

// Define the API endpoint

// Define a function to handle loading and displaying the list of books

// Define a function to handle form submission for adding a new book

// Attach event listeners to the button and form

// TODO: Add delete functionality
