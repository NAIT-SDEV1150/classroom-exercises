// Fetch utility function

// POST utility function

// TODO: Add DELETE function here
