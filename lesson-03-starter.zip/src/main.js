console.log('Lesson 03 starter loaded');

// Instructor TODO: 
// 1. Declare variables using var, let, const
// 2. Log their types with console.log(typeof …)
// 3. Try built-in functions: alert(), prompt(), parseInt(), toString()
// 4. Manipulate values and observe results in the console

// Student TODO: 
// Prompt the user for their name and age
// Log a greeting message using the provided name and age